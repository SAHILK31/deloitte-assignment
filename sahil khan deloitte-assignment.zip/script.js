function show(){
    let l=document.getElementById('share')
    l.style.display='block'
   
}
function hide(){
    let l=document.getElementById('share')
    l.style.display='none'
   
}






    






























